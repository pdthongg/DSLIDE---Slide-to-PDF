
const statusEl = document.getElementById("status");
const btn = document.getElementById("makepdf");
const barEl = document.getElementById("bar");
const pickedTitleEl = document.getElementById("pickedTitle");
function status(t){ statusEl.textContent = t; }
function setProgress(p){ if(!barEl) return; const v = Math.max(0, Math.min(1, p||0)); barEl.style.width = (v*100).toFixed(0) + "%"; }

btn.addEventListener("click", async () => {
  try{
    setProgress(0);
    status("Đang quét slide...");
    const { images, title } = await collectSlideInfo();
    const urls = images.map(x=>x.src);
    if(!urls.length){ status("Không tìm thấy ảnh DocImage.axd?page=... Hãy cuộn qua các slide rồi bấm lại."); return; }
    if(pickedTitleEl){ pickedTitleEl.textContent = title ? `Tên file: ${title}.pdf` : 'Tên file: (tự lấy từ trang)'; }

    status(`Đã tìm thấy ${urls.length} ảnh. Đang nhận tỷ lệ & tạo PDF...`);
    const preset = await inferPreset(urls[0]);
    const infos = await loadAllAsJPEG(urls); // [{bytes,w,h}, ...]
    const blob = await buildPdfFromImages(infos, preset);
    const fileUrl = URL.createObjectURL(blob);

    // Tên file theo tiêu đề
    let filename;
    if (title && title.trim()) {
      const safe = title.replace(/[\\/:*?"<>|]/g, "").trim();
      filename = (safe || "CTUMP_Slides") + ".pdf";
    } else {
      filename = "CTUMP_Slides.pdf";
    }

    await chrome.downloads.download({ url: fileUrl, filename, saveAs: false, conflictAction: "uniquify" });
    setProgress(1);
    status(`Đã tạo và tải: ${filename}`);
  }catch(e){
    console.error(e);
    status("Lỗi tạo PDF: " + (e?.message || e));
  }
});

async function collectSlideInfo(){
  const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
  if(!tab?.id) throw new Error("Không tìm thấy tab đang mở.");
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      const out = [];
      const pushUrl = (u)=>{
        try{
          const url = new URL(u, location.href);
          if(!/(^|\/ )?DocImage\.axd$/i.test(url.pathname)) return;
          const pageStr = url.searchParams.get("page");
          if(!/^\d+$/.test(pageStr||"")) return;
          if (url.searchParams.has("thumb")) return;
          if (url.searchParams.get("zoom") && url.searchParams.get("zoom") !== "100") return;
          if (!url.searchParams.get("token") || !url.searchParams.get("format")) return;
          const norm = new URL(url.href);
          norm.searchParams.delete("rnd");
          out.push({ src: norm.href, pageNum: Number(pageStr) });
        }catch(e){}
      };

      const imgs = Array.from(document.images || []);
      for(const el of imgs){
        if(el.currentSrc) pushUrl(el.currentSrc);
        if(el.src) pushUrl(el.src);
        const ss = el.srcset || "";
        for(const part of ss.split(",")){
          const u = part.trim().split(" ")[0];
          if(u) pushUrl(u);
        }
      }
      try{
        const perf = performance.getEntriesByType("resource") || [];
        for(const e of perf){ if(e.name) pushUrl(e.name); }
      }catch(e){}

      const titleEl = document.querySelector("h1.title-khoahoc.collapse-header");
      const title = titleEl ? (titleEl.textContent || titleEl.innerText || "").trim() : "";

      const seen = new Set();
      const images = out.filter(it => (seen.has(it.src)?false:(seen.add(it.src),true)))
                        .sort((a,b)=> (a.pageNum??1e9)-(b.pageNum??1e9) || a.src.localeCompare(b.src));
      return { images, title };
    }
  });

  let allImages = [];
  let pageTitle = "";
  for(const r of results){
    if(r.result){
      allImages = allImages.concat(r.result.images||[]);
      if(!pageTitle && r.result.title) pageTitle = r.result.title;
    }
  }
  return { images: allImages, title: pageTitle };
}

async function inferPreset(url){
  const img = new Image();
  img.src = url;
  await imgDecode(img);
  const ratio = img.naturalWidth / img.naturalHeight;
  if ((img.naturalWidth===1700 && img.naturalHeight===2200) || (ratio > 0.77 && ratio < 0.79)) return "1722";
  if ((img.naturalWidth===1920 && img.naturalHeight===1080) || (ratio > 1.76 && ratio < 1.79)) return "169";
  if ((img.naturalWidth===2000 && img.naturalHeight===1500) || (ratio > 1.32 && ratio < 1.34)) return "43";
  return "169";
}

function specOf(preset){
  switch(preset){
    case "1722": return { wpt: 17*72,   hpt: 22*72 };
    case "43":   return { wpt: 10*72,   hpt: 7.5*72 };
    case "169":  return { wpt: 11*72,   hpt: 6.1875*72 };
    default:     return { wpt: 11.69*72,hpt: 8.27*72 };
  }
}

async function loadAllAsJPEG(urls){
  const out = [];
  for (let i=0;i<urls.length;i++){
    setProgress(i/urls.length);
    status(`Đang xử lý ảnh ${i+1}/${urls.length}...`);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = urls[i];
    await imgDecode(img);
    const {bytes} = await toJpegBytes(img);
    out.push({ bytes, w: img.naturalWidth, h: img.naturalHeight });
  }
  setProgress(1);
  return out;
}

function imgDecode(img){
  return new Promise((res, rej)=>{
    if (img.complete && img.naturalWidth) return res();
    img.onload = ()=> res();
    img.onerror = ()=> rej(new Error("Không tải được ảnh"));
  });
}

async function toJpegBytes(img){
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
  const b64 = dataUrl.split(',')[1];
  const bin = atob(b64);
  const len = bin.length;
  const bytes = new Uint8Array(len);
  for(let i=0;i<len;i++){ bytes[i] = bin.charCodeAt(i); }
  return { bytes };
}

async function buildPdfFromImages(images, preset){
  const { wpt: pageW, hpt: pageH } = specOf(preset);

  const chunks = [];
  let offset = 0;
  const xref = new Map();
  const enc = (s)=> new TextEncoder().encode(s);
  const push = (s)=>{ const b = enc(s); chunks.push(b); offset += b.length; };
  const pushBin = (u8)=>{ chunks.push(u8); offset += u8.length; };

  let nextId = 1;
  const reserveId = ()=> nextId++;
  const addObjWithId = (id, body, streamBytes=null)=>{
    xref.set(id, offset);
    push(`${id} 0 obj\n`);
    push(body);
    if (streamBytes){
      push(`\nstream\n`);
      pushBin(streamBytes);
      push(`\nendstream`);
    }
    push(`\nendobj\n`);
    return id;
  };

  push('%PDF-1.4\n%\xFF\xFF\xFF\xFF\n');

  const pagesId = reserveId();
  const pageIds = [];

  for (let i=0;i<images.length;i++){
    const {bytes, w, h} = images[i];

    const imgId = reserveId();
    addObjWithId(imgId, `<< /Type /XObject /Subtype /Image /Filter /DCTDecode /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Length ${bytes.length} >>`, bytes);

    const imgRatio = w/h;
    const pageRatio = pageW/pageH;
    let drawW, drawH;
    if (imgRatio >= pageRatio){ drawW = pageW; drawH = pageW / imgRatio; }
    else { drawH = pageH; drawW = pageH * imgRatio; }
    const dx = (pageW - drawW)/2;
    const dy = (pageH - drawH)/2;

    const contentStream = `q\n1 0 0 1 ${dx.toFixed(2)} ${dy.toFixed(2)} cm\n${drawW.toFixed(2)} 0 0 ${drawH.toFixed(2)} 0 0 cm\n/Im Do\nQ`;
    const contId = reserveId();
    addObjWithId(contId, `<< /Length ${contentStream.length} >>\nstream\n${contentStream}\nendstream`);

    const resId = reserveId();
    addObjWithId(resId, `<< /XObject << /Im ${imgId} 0 R >> >>`);

    const pageId = reserveId();
    addObjWithId(pageId, `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources ${resId} 0 R /Contents ${contId} 0 R >>`);
    pageIds.push(pageId);
  }

  addObjWithId(pagesId, `<< /Type /Pages /Kids [${pageIds.map(id=>`${id} 0 R`).join(' ')}] /Count ${pageIds.length} >>`);
  const catalogId = reserveId();
  addObjWithId(catalogId, `<< /Type /Catalog /Pages ${pagesId} 0 R >>`);

  const xrefStart = offset;
  const maxId = nextId - 1;
  push(`xref\n0 ${maxId+1}\n`);
  push(`0000000000 65535 f \n`);
  for (let id=1; id<=maxId; id++){
    const pos = xref.get(id);
    const s = String(pos).padStart(10,'0');
    push(`${s} 00000 n \n`);
  }
  push(`trailer\n<< /Size ${maxId+1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefStart}\n%%EOF`);

  const total = chunks.reduce((a,c)=>a+c.length,0);
  const out = new Uint8Array(total);
  let off = 0;
  for(const c of chunks){ out.set(c, off); off += c.length; }
  return new Blob([out], { type: "application/pdf" });
}
